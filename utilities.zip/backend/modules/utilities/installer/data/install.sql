INSERT INTO `modules_settings` VALUES('utilities', 'classname_container', 's:7:"content";');
INSERT INTO `modules_settings` VALUES('utilities', 'fontsize_large', 'i:16;');
INSERT INTO `modules_settings` VALUES('utilities', 'fontsize_small', 'i:10;');